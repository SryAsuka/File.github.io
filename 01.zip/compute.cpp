/*
* Project: Module
* Author: Lixinhang
* File: Compute module
* Date: 2022.10.22
*/

#include<iostream>
#include<string>
#include<vector> 
#include<algorithm>
#include <limits>
using std::cout;   
using std::string; 
using std::domain_error;
using std::vector;          
using std::numeric_limits;   
using std::streamsize;

struct Grade{
  string ID;
  string name;
  double midtermGrade;
  double finalGrade;
  vector<double> homeworkGrade;
  double total;
};

double median(vector<double> vec)
{
	auto size=vec.size();
	if(size==0)
		throw domain_error("median of an empty vector");
	sort(vec.begin(),vec.end());
	auto mid=size/2;
	double median=(size%2==0?(vec[mid]+vec[mid-1])/2:vec[mid]);
	return median;
}

double score(const Grade& g)
{
	if(g.homeworkGrade.size()==0)
		throw domain_error{"student has done no homework"};
	return 0.2*g.midtermGrade+0.4*g.finalGrade+0.4*median(g.homeworkGrade);
}

bool compare(const Grade &g1,const Grade &g2){return g1.total<g2.total;}


void computeAndSortCourseGrades(vector<Grade> &cg)
{
	try{
		for(auto &g:cg)
			g.total=score(g);
		sort(cg.begin(),cg.end(),compare);
	}catch(domain_error &e){
		cout<<e.what();
	}
}
