/* 
* Project: Module 
* Author:Lixinhang
* File: Input module
* Date: 2022.10.22
*/

#include<iostream>
#include<string>
#include<vector>
#include<fstream>
#include<istream>
#include <limits>
using std::string;
using std::vector;
using std::cerr;
using std::cout; 
using std::istream; 
using std::ifstream;
using std::cin;
using std::numeric_limits;

struct Grade{
  string ID;
  string name;
  double midtermGrade;
  double finalGrade;
  vector<double> homeworkGrade;
  double total;
};

bool clearIstream(istream& in){
    if(!in){
        if(in.bad())
            throw std::ios_base::failure{"I/O error while reading"};
        if(in.eof()){
                std::cerr<<"eof has reached,isteam state is still eof.\n";
                return false;
            }
        in.clear();
        //std::cerr<<"clear fail,isteam state is good.\n";
        in.ignore(std::numeric_limits<std::streamsize>::max(),'\n');

    }
    return true;
}

istream& operator>>(istream& is,Grade& g)
{

	is>>g.ID>>g.name>>g.midtermGrade>>g.finalGrade;
	if(is){
		g.homeworkGrade.clear();
		for(double x;is>>x;)
		{
			g.homeworkGrade.push_back(x);
		}
    clearIstream(is);
	}
	return is;
}

void readCourseGrades(vector<Grade> &cg)
{
	cout<<"Reading all grades information from a file...\n\n"
		"Please enter your filename:";
	string s;
	cin>>s;
	ifstream ifs{s};
	for(Grade g;ifs>>g;)
	{
		cg.push_back(g);
	}
	if(cg.size()!=0){
		cerr <<"Reading successfully!\n\n";
	}else{
		cerr<<"There are some errors in the grade data.\n"
			"The program will exit.\n";
		exit(EXIT_FAILURE);
	}
}
