/* 
* Project: Module 
* Author:Lixinhang
* File: OutputCourseGrades module
* Date: 2022.10.22
*/

#include<iostream>
#include<string>
#include<vector>
using std::string;
using std::vector;
using std::cout; 
using std::endl;


struct Grade{
  string ID;
  string name;
  double midtermGrade;
  double finalGrade;
  vector<double> homeworkGrade;
  double total;
};


void outputCourseGrades(const vector<Grade> &cg)
{
	cout<<"SBI total grades:"<<endl<<std::showpoint;
	auto prec=cout.precision(3);
	for(const auto &g:cg){
		cout<<g.total<<string(20,' ')<<g.name<<'\n';
	}
	cout.precision(prec);
}