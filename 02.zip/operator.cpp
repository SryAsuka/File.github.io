/* 
* Project: Module 
* Author:Lixinhang
* File: Operator module
* Date: 2022.10.22
*/

#include<iostream>
#include<string>
#include<vector>
#include<istream>
using std::istream;
using std::string;
using std::vector;

struct Grade{
  string ID;
  string name;
  double midtermGrade;
  double finalGrade;
  vector<double> homeworkGrade;
  double total;
};

bool clearIstream(istream& in);

istream& operator>>(istream& is,Grade& g)
{

	is>>g.ID>>g.name>>g.midtermGrade>>g.finalGrade;
	if(is){
		g.homeworkGrade.clear();
		for(double x;is>>x;)
		{
			g.homeworkGrade.push_back(x);
		}
    clearIstream(is);
	}
	return is;
}