/*
* Project: Module
* Author: Lixinhang
* File: Compare module
* Date: 2022.10.22
*/

#include<iostream>
#include<string>
#include<vector>
using std::string; 
using std::vector; 


struct Grade{
  string ID;
  string name;
  double midtermGrade;
  double finalGrade;
  vector<double> homeworkGrade;
  double total;
};


bool compare(const Grade &g1,const Grade &g2){return g1.total<g2.total;}