/* 
* Project: Module 
* Author:Lixinhang
* File: ReadCourseGrades module
* Date: 2022.10.22
*/


#include<iostream>
#include<string>
#include<vector>
#include<fstream>
#include<istream>
#include <limits>
using std::string;
using std::vector;
using std::cerr;
using std::cout; 
using std::istream; 
using std::ifstream;
using std::cin;

struct Grade{
  string ID;
  string name;
  double midtermGrade;
  double finalGrade;
  vector<double> homeworkGrade;
  double total;
};

istream& operator>>(istream& is,Grade& g);

void readCourseGrades(vector<Grade> &cg)
{
	cout<<"Reading all grades information from a file...\n\n"
		"Please enter your filename:";
	string s;
	cin>>s;
	ifstream ifs{s};
	for(Grade g;ifs>>g;)
	{
		cg.push_back(g);
	}
	if(cg.size()!=0){
		cerr <<"Reading successfully!\n\n";
	}
	else{
		cerr<<"There are some errors in the grade data.\n"
			"The program will exit.\n";
		exit(EXIT_FAILURE);
	}
}