/*
* Project: Module
* Author:Lixinhang
* File: Main module
* Date: 2022.10.22
*/

#include<iostream>
#include<string>
#include<vector>
#include <iomanip>
#include<algorithm>
#include <limits>
#include <fstream>
using std::cout;
using std::istream;
using std::cin;
using std::string;
using std::domain_error;
using std::endl;
using std::vector;
using std::cerr;
using std::ifstream;
using std::numeric_limits;
using std::streamsize;

struct Grade{
  string ID;
  string name;
  double midtermGrade;
  double finalGrade;
  vector<double> homeworkGrade;
  double total;
};

void readCourseGrades(vector<Grade> &cg);
void computeAndSortCourseGrades(vector<Grade> &cg);
void outputCourseGrades(const vector<Grade> &cg);

int main()
{
    vector<Grade> courseGrades;
    readCourseGrades(courseGrades);
    computeAndSortCourseGrades(courseGrades);
    outputCourseGrades(courseGrades);
    return 0;
}
