/*
* Project: Module
* Author: Lixinhang
* File: ComputeAndSortCourseGrades module
* Date: 2022.10.22
*/

#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
#include<limits>
using std::cout;   
using std::string; 
using std::domain_error;
using std::vector;          
using std::numeric_limits;   
using std::streamsize;

struct Grade{
  string ID;
  string name;
  double midtermGrade;
  double finalGrade;
  vector<double> homeworkGrade;
  double total;
};

double median(vector<double> vec);
double score(const Grade& g);
bool compare(const Grade &g1,const Grade &g2);

void computeAndSortCourseGrades(vector<Grade> &cg)
{
	try{
		for(auto &g:cg)
			g.total=score(g);
		sort(cg.begin(),cg.end(),compare);
	}catch(domain_error &e){
		cout<<e.what();
	}
}
