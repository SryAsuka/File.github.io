/*
* Project: Module
* Author: Lixinhang
* File: Score module
* Date: 2022.10.22
*/

#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
#include<limits>
using std::cout;   
using std::string; 
using std::domain_error;
using std::vector;          
using std::numeric_limits;   
using std::streamsize;

struct Grade{
  string ID;
  string name;
  double midtermGrade;
  double finalGrade;
  vector<double> homeworkGrade;
  double total;
};

double median(vector<double> vec);

double score(const Grade& g)
{
	if(g.homeworkGrade.size()==0)
		throw domain_error{"student has done no homework"};
	return 0.2*g.midtermGrade+0.4*g.finalGrade+0.4*median(g.homeworkGrade);
}
