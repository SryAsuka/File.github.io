/* 
* Project: Module 
* Author:Lixinhang
* File: Clearistream module
* Date: 2022.10.22
*/

#include<iostream>
#include<string>
#include<vector>
#include<fstream>
#include<istream>
#include<limits>
using std::istream;
using std::ifstream;
using std::numeric_limits;

bool clearIstream(istream& in){
	if(!in){
		if(in.bad())
			throw std::ios_base::failure{"I/O error while reading"};
		if(in.eof()){
				std::cerr<<"eof has reached,isteam state is still eof.\n";
				return false;
			}
		in.clear();
		//std::cerr<<"clear fail,isteam state is good.\n";
		in.ignore(std::numeric_limits<std::streamsize>::max(),'\n');

	}
	return true;
}