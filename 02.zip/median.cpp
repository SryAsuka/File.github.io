/*
* Project: Module
* Author: Lixinhang
* File: Median module
* Date: 2022.10.22
*/

#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
#include<limits>
using std::string;
using std::domain_error;
using std::vector;
using std::numeric_limits;

double median(vector<double> vec)
{
	auto size=vec.size();
	if(size==0)
		throw domain_error("median of an empty vector");
	sort(vec.begin(),vec.end());
	auto mid=size/2;
	double median=(size%2==0?(vec[mid]+vec[mid-1])/2:vec[mid]);
	return median;
}
